#!/usr/bin/env python3

print("CrowdStrike")
print("We Stop Breaches")
