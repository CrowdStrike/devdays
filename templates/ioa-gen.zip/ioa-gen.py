import json
import boto3
import time
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

region_name = os.environ['region_name']
s3_bucket = os.environ['s3_bucket']
cloudtrail_name = os.environ['cloudtrail_name']


def lambda_handler(event, context):
    lambda_layer()
    bucket_versioning()
    cloudtrail()


def lambda_layer():
    lambda_client = boto3.client('lambda', region_name=region_name)
    try:
        layer_data = lambda_client.list_layers()['Layers'][0]
        layer_name = layer_data['LayerName']
        version_number = layer_data['LatestMatchingVersion']['Version']
        layer_versions = lambda_client.list_layer_versions(
            LayerName=layer_name,
        )

        response = lambda_client.add_layer_version_permission(
            Action='lambda:GetLayerVersion',
            LayerName=layer_name,
            Principal='*',
            StatementId='public',
            VersionNumber=version_number
        )
        logger.info('Added layer version permission to layer {}'.format(layer_name))
        time.sleep(5)
        response = lambda_client.remove_layer_version_permission(
            LayerName=layer_name,
            VersionNumber=version_number,
            StatementId='public'
        )
        logger.info('Removed layer version permission to layer {}'.format(layer_name))
    except Exception as e:
        logger.info('Got exception {} changing layer versions permission {}'.format(e, layer_name))
        pass
    return


def cloudtrail():
    try:
        cloudtrail_client = boto3.client('cloudtrail', region_name=region_name)
        this_cloudtrail_arn = cloudtrail_client.get_trail(Name=cloudtrail_name)['Trail']['TrailARN']
        stop_response = cloudtrail_client.stop_logging(Name=this_cloudtrail_arn)
        if stop_response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('Stopped logging on trail {}'.format(cloudtrail_name))
        time.sleep(2)
        start_response = cloudtrail_client.start_logging(Name=this_cloudtrail_arn)
        if stop_response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('Started logging on trail {}'.format(cloudtrail_name))
    except Exception as e:
        logger.info('Got exception {} disabling logging on trail {}'.format(cloudtrail_name))
        pass
    return


def bucket_versioning():
    # Suspend and enable versioning on an s3 bucket
    try:
        s3 = boto3.resource('s3', region_name=region_name)
        this_bucket_versioning = s3.BucketVersioning(s3_bucket)
        suspend_response = this_bucket_versioning.suspend()
        if suspend_response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('Suspended versioning on bucket {}'.format(s3_bucket))
        time.sleep(2)
        enable_response = this_bucket_versioning.enable()
        if enable_response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('Enabled versioning on bucket {}'.format(s3_bucket))
    except Exception as e:
        logger.info('Got exception {} disabling versioning on bucket {}'.format(e, s3_bucket))
        pass
    return