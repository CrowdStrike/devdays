import json
import logging
import os
import sys
import boto3
import requests
import time
from falconpy import CSPMRegistration

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# CONSTANTS
SUCCESS = "SUCCESS"
FAILED = "FAILED"

STACK_SET_NAME = "CrowdStrike-CSPM-Integration"

S3StagingBucket = os.environ['S3StagingBucket']
CSAccountNumber = os.environ['CSAccountNumber']
CSAssumingRoleName = os.environ['CSAssumingRoleName']
aws_region = os.environ['aws_region']
cloudtrail_region = os.environ['cloudtrail_region']
EnableIOA = os.environ['EnableIOA']
CSCloud = os.environ['CSCloud']
s3_prefix = os.environ['s3_prefix']


def cfnresponse_send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']
    print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']

    json_responseBody = json.dumps(responseBody)

    print("Response body:\n" + json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))


def load_cft(CFT, response):
    register_result = response['body']['resources'][0]
    logger.info('Account registration result: {}'.format(response))
    external_id = register_result['external_id']
    eventbus_name = register_result['eventbus_name']
    RoleName = register_result['iam_role_arn'].split('/')[-1]
    CSBucketName = register_result['aws_cloudtrail_bucket_name']
    CRWD_Discover_paramList = []
    keyDict = {'ParameterKey': 'ExternalID', 'ParameterValue': external_id}
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'RoleName'
    keyDict['ParameterValue'] = RoleName
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'ExternalID'
    keyDict['ParameterValue'] = external_id
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'CSRoleName'
    keyDict['ParameterValue'] = CSAssumingRoleName
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'CSAccountNumber'
    keyDict['ParameterValue'] = CSAccountNumber
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'EnableIOA'
    keyDict['ParameterValue'] = EnableIOA
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'CSBucketName'
    keyDict['ParameterValue'] = CSBucketName
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'CSEventBusName'
    keyDict['ParameterValue'] = eventbus_name
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'S3StagingBucket'
    keyDict['ParameterValue'] = S3StagingBucket
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'S3Prefix'
    keyDict['ParameterValue'] = s3_prefix
    CRWD_Discover_paramList.append(dict(keyDict))
    keyDict['ParameterKey'] = 'PermissionsBoundary'
    keyDict['ParameterValue'] = os.environ['permissions_boundary']
    CRWD_Discover_paramList.append(dict(keyDict))

    #
    # Delay the creation of the stack for Bucket ACL permissions to be replicated
    # We need to wait for the s3 bucket specified in the return parameters to be available
    #
    time.sleep(180)
    # path has the syntax dir/dir
    if s3_prefix == '':
        s3_path = '/'
    else:
        s3_path = '/' + s3_prefix + '/'

    CSPM_ROLE_TEMPLATE_URL = 'https://' + S3StagingBucket + '.s3.amazonaws.com' + s3_path + 'horizon-role.yaml'
    logger.info('template {}'.format(CSPM_ROLE_TEMPLATE_URL))
    logger.info('params {}'.format(CRWD_Discover_paramList))
    try:
        stack_info = CFT.create_stack(
            StackName=STACK_SET_NAME,
            TemplateURL=CSPM_ROLE_TEMPLATE_URL,
            Parameters=CRWD_Discover_paramList,
            TimeoutInMinutes=5,
            Capabilities=[
                'CAPABILITY_NAMED_IAM',
            ],
            # RoleARN='string',
            Tags=[
                {
                    'Key': 'Vendor',
                    'Value': 'CrowdStrike'
                },
            ],
        )
        return stack_info
    except Exception as e:
        logger.info('Exception creating CSPM template')
        return


def lambda_handler(event, context):
    logger.info('Got event {}'.format(event))
    logger.info('Context {}'.format(context))
    #  Exampe response to post request

    CFT = boto3.client('cloudformation')
    accountId = context.invoked_function_arn.split(":")[4]
    api_keys = event['ResourceProperties']
    FalconClientId = api_keys['FalconClientId']
    FalconSecret = api_keys['FalconSecret']
    falcon = CSPMRegistration(client_id=FalconClientId,
                              client_secret=FalconSecret,
                              base_url=CSCloud
                              )
    if event['RequestType'] in ['Create']:
        # Format post message
        try:
            # Execute the command by calling the named function
            response_data = {}
            logger.info('Event = {}'.format(event))
            response = falcon.create_aws_account(account_id=accountId, cloudtrail_region=aws_region)
            if response['status_code'] == 400:
                #
                # We have an error
                #
                error = response['body']['errors'][0]['message']
                logger.info('Account Registration Failed with reason....{}'.format(error))
                cfnresponse_send(event, context, FAILED, error, "CustomResourcePhysicalID")
            elif response['status_code'] == 201:
                load_cft(CFT, response)
                if load_cft:
                    logger.info('Created Stack {}')
                    cfnresponse_send(event, context, SUCCESS, load_cft, "CustomResourcePhysicalID")
                else:
                    cfnresponse_send(event, context, FAILED, "No Stack", "CustomResourcePhysicalID")
            else:
                logger.info('Got error {}'.format(error=response['body']))
                cfnresponse_send(event, context, FAILED, "No Stack", "CustomResourcePhysicalID")
        except Exception as err:  # noqa: E722
            # We can't communicate with the endpoint
            logger.info('Registration Failed {}'.format(err))
            cfnresponse_send(event, context, FAILED, err, "CustomResourcePhysicalID")

    elif event['RequestType'] in ['Update']:
        logger.info('Event = ' + event['RequestType'])
        cfnresponse_send(event, context, SUCCESS, "CustomResourcePhysicalID")

    elif event['RequestType'] in ['Delete']:
        logger.info('Event = ' + event['RequestType'])
        response = falcon.delete_aws_account(ids=accountId)
        CFT.delete_stack(
            StackName="CrowdStrike-CSPM-Integration")
        cfnresponse_send(event, context, 'SUCCESS', response, "CustomResourcePhysicalID")



