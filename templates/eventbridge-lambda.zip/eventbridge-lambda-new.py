import json
import os
import boto3
import logging
import urllib3

logger = logging.getLogger()
logger.setLevel(logging.INFO)
http = urllib3.PoolManager()
SUCCESS = "SUCCESS"
FAILED = "FAILED"


def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']
    logger.info('Got event {}'.format(event))
    print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']

    json_responseBody = json.dumps(responseBody)

    print("Response body:\n" + json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:

        response = http.request('PUT', responseUrl, body=json_responseBody.encode('utf-8'), headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing https post(..): " + str(e))


def lambda_handler(event, context):
    EventBus = event['ResourceProperties']['EventBus']
    CS_CURRENT_ACCOUNT = os.environ['CS_CURRENT_ACCOUNT']
    RuleName = 'cs-cloudtrail-events-ioa-rule'
    RoleArn = 'arn:aws:iam::' + CS_CURRENT_ACCOUNT + ':role/CrowdStrikeCSPMEventBridge'
    ec2 = boto3.client('ec2')
    regions = [region['RegionName'] for region in ec2.describe_regions()['Regions']]
    print(regions)
    if event['RequestType'] in ['Create']:
        for region in regions:
            try:
                client = boto3.client('events', region_name=region)
                logger.info('Processing region {}'.format(region))
                response = client.put_rule(
                    Name=RuleName,
                    EventPattern='{"detail-type":["AWS API Call via CloudTrail",'
                                 '"AWS Console Sign In via CloudTrail",'
                                 '"AWS Service Event via CloudTrail"]}',
                    State='ENABLED',
                    RoleArn=RoleArn
                )
                put_response = client.put_targets(
                    Rule=RuleName,
                    Targets=[
                        {
                            'Id': RuleName,
                            'Arn': EventBus,
                            'RoleArn': RoleArn
                        }
                    ]
                )
                if put_response['ResponseMetadata']['HTTPStatusCode'] == 200 and put_response['ResponseMetadata'][
                        'HTTPStatusCode'] == 200:
                        logger.info('Added Region {}'.format(region))
                else:
                        logger.info('Problem adding Region {}'.format(region))
            except Exception as e:
                logger.info('Got execption {} processing region {}'.format(e, region))
                pass
        send(event, context, SUCCESS, {}, "{} metrics".format(RuleName))
    elif event['RequestType'] in ['Delete']:
        # Format post message
        for region in regions:
            try:
                client = boto3.client('events', region_name=region)
                logger.debug('Processing region {}'.format(region))
                targets = client.list_targets_by_rule(
                    Rule=RuleName
                )
                target_id=targets['Targets'][0]['Id']
                logger.info('target id is {} in region {}'.format(target_id, region))
                response = client.remove_targets(
                    Rule=RuleName,
                    Ids=[
                        target_id,
                    ]
                )
                logger.info('remove target response {}'.format(response))
                response = client.delete_rule(
                    Name=RuleName
                )
            except Exception as e:
                logger.info('Got execption {} processing region {}'.format(e, region))
                pass
        send(event, context, SUCCESS, {}, "{} metrics".format(RuleName))





